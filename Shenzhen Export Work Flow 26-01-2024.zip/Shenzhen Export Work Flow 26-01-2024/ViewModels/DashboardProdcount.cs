﻿namespace APACExportTrackX.ViewModels
{
    public class DashboardProdcount
    {
        public int Received { get; set; }
        public int WIP { get; set; }
        public int Completed { get; set; }
        public int Pending { get; set; }
        public int UnAllocated { get; set; }
        public int Query { get; set; }
        public int etd10 { get; set; }
        public int etd12 { get; set; }
        public int etd18 { get; set; }
        public int siCutOff { get; set; }
    }
}
