﻿using APACExportTrackX.DataModel;

namespace ShenzhenExportTrackX.ViewModels
{
    public class ResetPasswordViewModel
    {
        public IEnumerable<ApplicationUser> Users { get; set; }
        public string SelectedUserId { get; set; }
    }
}
