﻿using APACExportTrackX.DataModel;

namespace APACExportTrackX.ViewModels
{
	public class UploadViewModel
	{
		public int CountryId { get; set; }
		public IFormFile File { get; set; }
	}
}
