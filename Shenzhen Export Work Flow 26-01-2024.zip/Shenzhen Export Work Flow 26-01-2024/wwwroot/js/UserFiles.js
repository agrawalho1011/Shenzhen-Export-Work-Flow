﻿
//let searchValue = null,
//    statusValue = null,
//    startDateValue = null,
//    endDateValue = null,
//    tallySheetIdValue = null,
//    mblReviewIdValue = null,
//    tallySheetCommentValue = null,
//    mblReviewCommentValue = null,
//    fileComments = null;
//$(document).ready(function () {
//    $('.select2').select2();
//    getTableData(GetFilesUrl);
//    var activityList = activityIdDataList[0];
//    var activityId = activityList.id;
//    var activity = activityList.nameOfActivity;
//    $('#hiddenLabel').text(activity);
//    $('#hiddenLabelId').val(activityId);
//});

//function showInsertActivityPopUp(fileId) {
//    $.ajax({
//        url: FileActivityUrl + '?Id=' + fileId,
//        type: 'GET',
//        success: function (data) {
//            $('#modal-content').html(data);
//            $('#modal-content').modal();
//        },
//        error: function () {
//            alert("There is some problem in the service!")
//        }
//    });
//}

//function showCreateFilePopUp() {
//    $.ajax({
//        url: CreateFileUrl,
//        type: 'GET',
//        success: function (data) {
//            $('#modal-content').html(data);
//            $('#modal-content').modal();
//            $('#FileNo').on('blur', validateFileNumber);
//        },
//        error: function () {
//            alert("There is some problem in the service!")
//        }
//    });
//}

//function showInsertFilePopUp() {
//    $('.select2').select2();
//    setFormattedDateTime();

//    $.ajax({
//        url: InsertFileUrl,
//        type: 'GET',
//        success: function (data) {
//            $('#modal-content').html(data);
//            $('#modal-content').modal();

//            $('#countryList').select2({
//                placeholder: '-- Select Country --',
//            });

//            $.getScript('/js/Validation.js', function () {
//                // Bind the blur event handlers
//                $('#countryList option:selected').on('blur', validateCountry);
//                $('#FileNo').on('blur', validateFileNumber);
//                $('#ContainerNo').on('blur', validateContainer);
//                $('#ETD').on('blur', validateETD);
//                $('#ETAPOD').on('blur', validateETAPOD);
//                $('#ETA').on('blur', validateETA);
//                $('#DraftCutOff').on('blur', validateSICutOff);
//                $('#ATD').on('blur', validateATD);

//                const fileNo = $('#FileNo').val();
//                if (fileNo) {
//                    filenoChange();
//                }

//                $('#AddContainerButton').on('click', addContainer);
//                $('#SaveContainerButton').on('click', saveContainer);
//            });
//        },
//        error: function () {
//            alert("There is some problem in the service!");
//        }
//    });
//}


//function InsertFile() {
//    const FileActivitiesArray = [];
//    const FileActivitiesModel = {
//        ActivityId: $('#Activity').val(),
//        StatusId: $('#Status').val(),
//        Comment: $('#Comment').val()
//    };

//    FileActivitiesArray.push(FileActivitiesModel);

//    const selectedCountry = $('#countryList option:selected').val();
//    const fileNo = $('#FileNo').val();
//    const etd = $('#ETD').val();
//    const etapod = $('#ETAPOD').val();
//    const eta = $('#ETA').val();
//    const atd = $('#ATD').val();

//    if (!selectedCountry || selectedCountry === "none" || selectedCountry === "--Select--") {
//        toastr.warning('Please select country');
//        return;
//    }

//    if (!fileNo) {
//        toastr.warning('Please select file number');
//        return;
//    }

//    if (!etd) {
//        toastr.warning('Please select ETD');
//        return;
//    }

//    if (!etapod) {
//        toastr.warning('Please select ETAPOD');
//        return;
//    }

//    if (!eta) {
//        toastr.warning('Please select ETA');
//        return;
//    }

//    if (!atd) {
//        toastr.warning('Please select ATD');
//        return;
//    }

//    const FileAddActivityLogModel = {
//        CountryId: selectedCountry,
//        FileNumber: fileNo,
//        Container: $('#ContainerNo').val(),
//        ETD: etd,
//        ETAPOD: etapod,
//        ETA: eta,
//        SICutOff: $('#DraftCutOff').val(),
//        ATD: atd,
//        TotalHBL: $('#total').val(),
//        FileContact: $('#fileContact').val(),
//        ShippingAgent: $('#shippingAgent').val(),
//        ShippingLine: $('#shippingLine').val(),
//        FileActivities: FileActivitiesArray,
//        StartDateTime: $('#dateTime').val()
//    };

//    console.log(FileAddActivityLogModel);

//    $.ajax({
//        type: "post",
//        url: AddFileNewActivityUrl,
//        data: FileAddActivityLogModel,
//        datatype: "json",
//        cache: false,
//        success: function (data) {
//            if (data == "Error while processing the request") {
//                toastr.error('Error while processing the request.');
//            } else if (data == "Duplicate") {
//                toastr.warning('Activity with the same name already exists');
//            } else {
//                toastr.success('File Inserted Successfully..!!');
//                setTimeout(function () {
//                    // location.reload();
//                    $('#modal-content').modal('hide');
//                    $("#modal-content").hide();
//                    $('#filesTable').DataTable().ajax.reload();
//                }, 5000);
//            }
//        },
//        error: function (xhr) {
//            toastr.error('Unable to update. Service error!');
//        }
//    });
//}



//function showCreateHBLPopUp() {
//    $('.select2').select2();
//    setFormattedDateTime();

//    $.ajax({
//        url: CreateHBLUrl,
//        type: 'GET',
//        success: function (data) {
//            $('#modal-content').html(data);
//            $('#modal-content').modal();
//            $('.select2').select2();
//            $.getScript('/js/Validation.js', function () {
//                $('#HBLFileNo').on('blur', validateFileNumber);
//                $('#Container').on('blur', validateContainer);
//                $('#Comment').on('blur', validateComment);
//                $('#HBLNo').on('blur', validateHBL);

//                const fileNo = $('#HBLFileNo').val();
//                if (fileNo) {
//                    fileChange();
//                }

//                $('#AddContainerButton').on('click', addContainer);
//                $('#SaveContainerButton').on('click', saveContainer);
//            });
//        },
//        error: function () {
//            alert("There is some problem in the service!");
//        }
//    });
//}


//function saveHBL() {
//    const HBLActivitiesArray = [];
//    const HBLActivitiesModel = {
//        ActivityId: $('#HBLActivity').val(),
//        StatusId: $('#HBLStatus').val(),
//        Comment: $('#Comment').val()
//    };

//    HBLActivitiesArray.push(HBLActivitiesModel);

//    const HBLFileNo = $('#HBLFileNo').val();
//    const HBLNo = $('#HBLNo').val();
//    const HBLActivitySelected = $('#HBLActivity option:selected').val();
//    const HBLStatusSelected = $('#HBLStatus option:selected').val();

//    if (!HBLFileNo) {
//        toastr.warning('Please enter file number');
//        return;
//    }
//    if (!HBLNo) {
//        toastr.warning('Please enter HBL number');
//        return;
//    }
//    if (!HBLActivitySelected || HBLActivitySelected === 'none') {
//        toastr.warning('Please select an activity');
//        return;
//    }
//    if (!HBLStatusSelected || HBLStatusSelected === 'none') {
//        toastr.warning('Please select a status');
//        return;
//    }

//    const HBLUserViewModel = {
//        CountryId: $('#HBLcountryLists').val(),
//        FileNo: HBLFileNo,
//        Container: $('#Container').val(),
//        BookingNo: $('#BookingNo').val(),
//        HBL_No: HBLNo,
//        CustomerName: $('#Customer').val(),
//        StartDateTime: $('#dateTime').val(),
//        HBLActivities: HBLActivitiesArray
//    };

//    console.log(HBLActivitiesArray);
//    console.log(HBLUserViewModel);

//    $.ajax({
//        type: 'post',
//        url: AddNewHBLActivityUrl,
//        data: HBLUserViewModel,
//        datatype: 'json',
//        cache: false,
//        success: function (data) {
//            if (data == 'Error while processing the request') {
//                toastr.error('Error while processing the request.');
//            } else if (data == 'Duplicate') {
//                toastr.warning('Activity with the same name already exists');
//            } else if (data == 'File does not exist, first insert file') {
//                toastr.warning('File does not exist, first insert the file.');
//            } else if (data == 'HBL no is already added') {
//                toastr.warning('HBL no is already added.');
//            } else {
//                toastr.success('HBL Inserted Successfully..!!');
//                setTimeout(function () {
//                    $('#modal-content').modal('hide');
//                    $('#modal-content').hide();
//                    $('#hblTable').DataTable().ajax.reload();
//                }, 5000);
//            }
//        },
//        error: function (xhr) {
//            toastr.error('Unable to update. Service error!');
//        }
//    });
//}


//function fileChange() {
//    const fileNo = $('#HBLFileNo').val();

//    $.ajax({
//        type: "GET",
//        url: GetContainerUrl,
//        data: {
//            fileNo: fileNo
//        },
//        dataType: "json",
//        cache: false,
//        success: function (data) {
//            if (data.success === "Error while processing the request") {
//                toastr.error('Error while processing the request.');
//            } else if (data === "Duplicate") {
//                toastr.warning('Activity with the same name already exists');
//            } else if (data === "File does not exist first insert file") {
//                toastr.warning('File does not exist first insert file.');
//            } else if (data === "HBL no is already added") {
//                toastr.warning('HBL no is already added.');
//            } else {
//                const containerSelect = $('#Container');
//                containerSelect.empty();
//                containerSelect.append($('<option>').val('').text('-- Select Container --'));
//                $.each(data.containerList, function (index, container) {
//                    containerSelect.append($('<option>').val(container.id).text(container.containerNo));
//                });
//                // Refresh the select2 control
//                containerSelect.trigger('change');
//            }
//        },
//        error: function () {
//            toastr.error('Unable to update. Service error!');
//        }
//    });
//}


//function filenoChange() {
//    const fileNo = $('#FileNo').val();
//    console.log("fileNo", fileNo);

//    $.ajax({
//        type: "GET",
//        url: GetContainerUrl,
//        data: { fileNo: fileNo },
//        dataType: "json",
//        cache: false,
//        success: function (data) {
//            if (data.success === "Error while processing the request") {
//                toastr.error('Error while processing the request.');
//            } else if (data === "Duplicate") {
//                toastr.warning('Activity with the same name already exists.');
//            } else if (data === "File does not exist, first insert file") {
//                toastr.warning('File does not exist, first insert file.');
//            } else if (data === "HBL no is already added") {
//                toastr.warning('HBL no is already added.');
//            } else {
//                const containerSelect = $('#Container');
//                containerSelect.empty();
//                containerSelect.append($('<option>').val('').text('-- Select Container --'));
//                $.each(data.containerList, function (index, container) {
//                    containerSelect.append($('<option>').val(container.id).text(container.containerNo));
//                });
//                // Refresh the select2 control
//                containerSelect.trigger('change');
//            }
//        },
//        error: function (xhr) {
//            toastr.error('Unable to update. Service error!');
//        }
//    });
//}

//function addContainer(event) {
//    event.preventDefault();
//    event.stopPropagation();
//    $('#AddContainerButton').hide();
//    $('#AddContainerInputSection').show();
//}

//function saveContainer() {
//    var containerInputValue = $('#ContainerInput').val();
//    if (containerInputValue) {
//        var containerSelect = $('#Container');
//        var newOption = $('<option>').val(containerInputValue).text(containerInputValue);
//        containerSelect.append(newOption);
//        containerSelect.val(containerInputValue).trigger('change');
//        $('#ContainerInput').val('');
//        $('#AddContainerInputSection').hide();
//        $('#AddContainerButton').show();
//    }
//}





//function getTableData(GetFilesUrl) {
//    var activityList = activityIdDataList[0];
//    var activityName = activityList.nameOfActivity;
//    var activityType = activityList.activityType;
//    if (activityName === "SI To Carrier") {
//        table = $('#filesTable').DataTable({
//            paging: true,
//            scrollX: true,
//            scroller: true,
//            processing: true,
//            serverSide: true,
//            scrollY: avail_height < 400 ? avail_height - 120 : avail_height - 140,
//            info: true,
//            orderCellsTop: true,
//            fixedColumns: {
//                leftColumns: 4
//            },
//            "ajax": {
//                "url": GetFilesUrl,
//                "type": "POST",
//                "data": function (d) {
//                    d.fileNumber = $('#FileNumber').val();
//                    d.activity = activityName;
//                    d.search = searchValue;
//                    d.type = activityType;

//                }
//            },
//            "columns": [
//                {
//                    "data": null
//                },
//                { "data": "id", "name": "id", "label": "Id", "visible": false },
//                {
//                    "data": "enterDate", "name": "enterDate", "label": "Received Date", "autoWidth": true, render: function (data, type, full, meta) {
//                        return formatDate(data)
//                    }
//                },
//                { "data": "fileNumber", "name": "fileNumber", "label": "File#", "autoWidth": true },
//                { "data": "pod", "name": "pod", "label": "POD", "autoWidth": true },
//                {
//                    "data": "etd", "name": "etd", "label": "ETD", "autoWidth": true, render: function (data, type, full, meta) {
//                        return formatDate(data)
//                    }
//                },
//                {
//                    "data": "etapod", "name": "etapod", "label": "ETAPOD", "autoWidth": true, render: function (data, type, full, meta) {
//                        return formatDate(data)
//                    }
//                },
//                {
//                    "data": "eta", "name": "eta", "label": "ETA", "autoWidth": true, render: function (data, type, full, meta) {
//                        return formatDate(data)
//                    }
//                },
//                {
//                    "data": "atd", "name": "atd", "label": "ATD", "autoWidth": true, render: function (data, type, full, meta) {
//                        return formatDate(data)
//                    }
//                },
//                {
//                    "data": "siCutOff", "name": "siCutOff", "label": "SI Cut Off", "autoWidth": true, contenteditable: true, render: function (data, type, full, meta) {
//                        return formatDate(data)
//                    }
//                },
//                { "data": "fileContact", "name": "fileContact", "label": "File Contact", "autoWidth": true },
//                { "data": "containerNo", "name": "containerNo", "label": "Container#", "autoWidth": true, contenteditable: true },
//                { "data": "totalHBL", "name": "totalHBL", "label": "Total HBL", "autoWidth": true },
//                { "data": "statusId", "name": "statusId", "label": "Status", "autoWidth": true, contenteditable: true },
//                { "data": "comment", "name": "comment", "label": "Comment", contenteditable: true },
//                { "data": "tallySheetId", "name": "tallySheetId", "label": "Tally Sheet Status", contenteditable: true, "visible": false, visible: activityName === "SI To Carrier" },
//                { "data": "tallySheetComment", "name": "tallySheetComment", "label": "Tally Sheet Comment", contenteditable: true, "visible": false, visible: activityName === "SI To Carrier" },
//                { "data": "mblReviewId", "name": "mblReviewId", "label": "MBL Review Status", contenteditable: true, "visible": false, visible: activityName === "SI To Carrier" },
//                { "data": "mblReviewComment", "name": "mblReviewComment", "label": "MBL Review Comment", contenteditable: true, "visible": false, visible: activityName === "SI To Carrier" },
//                {
//                    "data": null, "autoWidth": true,
//                    "render": function (data, type, row, meta) {
//                        if (data.userId === data.currentUser || data.userId === null) {
//                            return '<button type="button" class=" edit-btn btn btn-default mr-1"><i class="fa fa-edit" style="color: green;"></i></button>'
//                        }
//                        else {
//                            return '';
//                        }


//                    }

//                },

//            ],
//            "columnDefs":
//                [
//                    {
//                        className: 'dt-control',
//                        orderable: false,
//                        data: null,
//                        defaultContent: '',
//                        targets: 0,
//                        width: "1%"
//                    },
//                    { 'visible': false, 'targets': [1] },
//                ],
//            "createdRow": function (row, data, dataIndex) {
//                if (data.userId !== null && data.statusId === "Pending") {
//                    if (data.userId == data.currentUser) {
//                        $(row).addClass('highlight-color');
//                    }
//                }
//            }

//        });

//    }
//    else {
//        table = $('#filesTable').DataTable({
//            paging: true,
//            scrollX: true,
//            scroller: true,
//            processing: true,
//            serverSide: true,
//            scrollY: avail_height < 400 ? avail_height - 120 : avail_height - 140,
//            info: true,
//            orderCellsTop: true,
//            fixedColumns: {
//                leftColumns: 4
//            },
//            "ajax": {
//                "url": GetFilesUrl,
//                "type": "POST",
//                "data": function (d) {
//                    d.fileNumber = $('#FileNumber').val();
//                    d.activity = activityName;
//                    d.search = searchValue;
//                    d.type = activityType;

//                }
//            },
//            "columns": [
//                {
//                    "data": null
//                },
//                { "data": "id", "name": "id", "label": "Id", "visible": false },
//                {
//                    "data": "enterDate", "name": "enterDate", "label": "Received Date", "autoWidth": true, render: function (data, type, full, meta) {
//                        return formatDate(data)
//                    }
//                },
//                { "data": "fileNumber", "name": "fileNumber", "label": "File#", "autoWidth": true },
//                { "data": "pod", "name": "pod", "label": "POD", "autoWidth": true },
//                {
//                    "data": "etd", "name": "etd", "label": "ETD", "autoWidth": true, render: function (data, type, full, meta) {
//                        return formatDate(data)
//                    }
//                },
//                {
//                    "data": "etapod", "name": "etapod", "label": "ETAPOD", "autoWidth": true, render: function (data, type, full, meta) {
//                        return formatDate(data)
//                    }
//                },
//                {
//                    "data": "eta", "name": "eta", "label": "ETA", "autoWidth": true, render: function (data, type, full, meta) {
//                        return formatDate(data)
//                    }
//                },
//                {
//                    "data": "atd", "name": "atd", "label": "ATD", "autoWidth": true, render: function (data, type, full, meta) {
//                        return formatDate(data)
//                    }
//                },
//                {
//                    "data": "siCutOff", "name": "siCutOff", "label": "SI Cut Off", "autoWidth": true, contenteditable: true, render: function (data, type, full, meta) {
//                        return formatDate(data)
//                    }
//                },
//                { "data": "fileContact", "name": "fileContact", "label": "File Contact", "autoWidth": true },
//                { "data": "containerNo", "name": "containerNo", "label": "Container#", "autoWidth": true, contenteditable: true },
//                { "data": "totalHBL", "name": "totalHBL", "label": "Total HBL", "autoWidth": true },
//                { "data": "statusId", "name": "statusId", "label": "Status", "autoWidth": true, contenteditable: true },
//                { "data": "comment", "name": "comment", "label": "Comment", contenteditable: true },
//                {
//                    "data": null, "autoWidth": true,
//                    "render": function (data, type, row, meta) {
//                        if (data.userId === data.currentUser || data.userId === null) {
//                            return '<button type="button" class=" edit-btn btn btn-default mr-1"><i class="fa fa-edit" style="color: green;"></i></button>'
//                        }
//                        else {
//                            return '';
//                        }


//                    }

//                },

//            ],
//            "columnDefs":
//                [
//                    {
//                        className: 'dt-control',
//                        orderable: false,
//                        data: null,
//                        defaultContent: '',
//                        targets: 0,
//                        width: "1%"
//                    },
//                    { 'visible': false, 'targets': [1] },
//                ],
//            "createdRow": function (row, data, dataIndex) {
//                if (data.userId !== null && data.statusId === "Pending") {
//                    if (data.userId == data.currentUser) {
//                        $(row).addClass('highlight-color');
//                    }
//                }
//            }

//        });

//    }
//}

//$('#search-row input').on('keyup change', function () {
//    table.settings()[0].oFeatures.bServerSide = false; // set serverSide back to false
//    var i = $(this).parent().index() + 1;
//    var searchstring = this.value.toString().trim();
//    table.column(i).search(searchstring).draw();
//    table.settings()[0].oFeatures.bServerSide = true; // set serverSide back to true

//});

//$('#filesTable').on('click', '.cancel-btn', function () {
//    const row = $(this).closest('tr');
//    const sicell = table.cell(row, 9);
//    const containercell = table.cell(row, 11);
//    const statuscell = table.cell(row, 13);
//    const commentcell = table.cell(row, 14);
//    const si = sicell.node().querySelector('input').value;
//    const containerNo = containercell.node().querySelector('input').value;
//    const activityList = activityIdDataList[0];
//    const activity = activityList.id;
//    const activityName = activityList.nameOfActivity;

//    let tallySheetIdcell, mblReviewIdcell, tallySheetcommentcell, mblReviewcommentcell;
//    let tallySheet, mblReview, tallySheetComment, mblReviewComment;

//    if (activityName === "SI To Carrier") {
//        tallySheetIdcell = table.cell(row, 15);
//        tallySheetcommentcell = table.cell(row, 16);
//        mblReviewIdcell = table.cell(row, 17);
//        mblReviewcommentcell = table.cell(row, 18);

//        tallySheet = tallySheetIdcell.node().querySelector('select').value;
//        mblReview = mblReviewIdcell.node().querySelector('select').value;
//        tallySheetComment = tallySheetcommentcell.node().querySelector('input').value;
//        mblReviewComment = mblReviewcommentcell.node().querySelector('input').value;
//    }

//    const status = statuscell.node().querySelector('select').value;
//    const comment = commentcell.node().querySelector('input').value;
//    const startDate = $('#dateTime').val();
//    const rowData = table.row(row).data();

//    const FileActivityLogViewModel = {
//        FileId: rowData.id,
//        ActivityId: activity,
//        StatusId: status,
//        Comment: comment,
//        SI: si,
//        ContainerId: rowData.containerId,
//        ContainerNo: containerNo,
//        StartDate: startDate,
//        UserId: rowData.userId,
//        TallySheetId: tallySheet,
//        MBLReviewId: mblReview,
//        TallySheetComment: tallySheetComment,
//        MBLReviewComment: mblReviewComment,
//    };

//    $.ajax({
//        type: "post",
//        url: AddFileActivitiesUrl,
//        data: {
//            model: FileActivityLogViewModel,
//            button: "Cancel",
//            statusValue: statusValue,
//            startDateValue: startDateValue,
//            endDateValue: endDateValue,
//            tallySheet: tallySheetIdValue,
//            mblReview: mblReviewIdValue,
//            tallySheetComments: tallySheetCommentValue,
//            mblReviewComments: mblReviewCommentValue,
//            fileComments: fileComments
//        },
//        datatype: "json",
//        cache: false,
//        success: function (data) {
//            if (data === "Error while processing the request") {
//                toastr.error('Error while processing the request.');
//                setTimeout(function () {
//                    location.reload();
//                }, 2000);
//            } else if (data === "Please select activitiy" || data === "Please select status") {
//                setTimeout(function () {
//                }, 2000);
//            } else {
//                sicell.node().contenteditable = false;
//                containercell.node().contenteditable = false;
//                statuscell.node().contenteditable = false;
//                commentcell.node().contenteditable = false;
//                if (activityName === "SI To Carrier") {
//                    tallySheetIdcell.node().contenteditable = false;
//                    mblReviewIdcell.node().contenteditable = false;
//                    tallySheetcommentcell.node().contenteditable = false;
//                    mblReviewcommentcell.node().contenteditable = false;
//                }
//                setTimeout(function () {
//                    $('#filesTable').DataTable().ajax.reload();
//                }, 2000);
//            }
//        },
//        error: function (xhr) {
//            toastr.error('Unable to update. Service error !');
//        }
//    });

//    sicell.node().contenteditable = false;
//    containercell.node().contenteditable = false;
//    statuscell.node().contenteditable = false;
//    commentcell.node().contenteditable = false;
//    if (activityName === "SI To Carrier") {
//        tallySheetIdcell.node().contenteditable = false;
//        mblReviewIdcell.node().contenteditable = false;
//        tallySheetcommentcell.node().contenteditable = false;
//        mblReviewcommentcell.node().contenteditable = false;
//    }
//    $(this).siblings('.cancel-btn').remove();
//    $(this).siblings('.save-button').remove();
//    $(this).removeClass().addClass('btn btn-default edit-btn').html('<i class="fa fa-edit" style="color: green;"></i>');
//    $('.edit-btn').not(this).prop('disabled', false);
//});



//$('#filesTable').on('click', '.edit-btn', function () {
//    setFormattedDateTime();

//    const row = $(this).closest('tr');
//    const sicell = table.cell(row, 9);
//    const containercell = table.cell(row, 11);
//    const statuscell = table.cell(row, 13);
//    const commentcell = table.cell(row, 14);
//    const sidata = sicell.data();
//    const containerdata = containercell.data();
//    const comment = commentcell.data();
//    const status = statuscell.data();
//    statusValue = status;
//    startDateValue = $('#dateTime').val();
//    const rowData = table.row(row).data();
//    endDateValue = rowData.endDate;
//    fileComments = rowData.comment;

//    const activityList = activityIdDataList[0];
//    const activity = activityList.id;
//    const activityName = activityList.nameOfActivity;
//    let tallySheetIdcell, tallySheetcommentcell, mblReviewIdcell, mblReviewcommentcell,
//        tallySheet, mblReview, tallySheetComent, mblReviewComment;

//    if (activityName === "SI To Carrier") {
//        tallySheetIdcell = table.cell(row, 15);
//        tallySheetcommentcell = table.cell(row, 16);
//        mblReviewIdcell = table.cell(row, 17);
//        mblReviewcommentcell = table.cell(row, 18);

//        tallySheet = tallySheetIdcell.data();
//        mblReview = mblReviewIdcell.data();
//        tallySheetComent = tallySheetcommentcell.data();
//        mblReviewComment = mblReviewcommentcell.data();

//        tallySheetIdValue = rowData.tallySheetId;
//        mblReviewIdValue = rowData.mblReviewId;
//        tallySheetCommentValue = rowData.tallySheetComment;
//        mblReviewCommentValue = rowData.mblReviewComment;
//    }

//    const startDate = $('#dateTime').val();
//    const FileActivityLogViewModel = {
//        FileId: rowData.id,
//        ActivityId: activity,
//        StatusId: status,
//        Comment: comment,
//        SI: sidata,
//        ContainerId: rowData.containerId,
//        StartDate: startDate,
//        ContainerNo: containerdata,
//        UserId: rowData.userId,
//        TallySheetId: tallySheet,
//        MBLReviewId: mblReview,
//        TallySheetComment: tallySheetComent,
//        MBLReviewComment: mblReviewComment,
//    };

//    console.log("Data:" + FileActivityLogViewModel);

//    $.ajax({
//        type: "post",
//        url: AddFileActivitiesUrl,
//        data: {
//            model: FileActivityLogViewModel,
//            button: "Edit",
//            statusValue: statusValue,
//            startDateValue: startDateValue,
//            endDateValue: endDateValue,
//            tallySheet: tallySheetIdValue,
//            mblReview: mblReviewIdValue,
//            tallySheetComments: tallySheetCommentValue,
//            mblReviewComments: mblReviewCommentValue,
//            fileComments: fileComments,
//        },
//        datatype: "json",
//        cache: false,
//        success: function (data) {
//            if (data === "Error while processing the request") {
//                toastr.error('Error while processing the request.');
//                setTimeout(function () {
//                //    location.reload();
//                }, 5000);
//            } else if (data === "Please select activitiy") {
//                toastr.error('Please select activitiy.');
//                setTimeout(function () {
//                //    $('#filesTable').DataTable().ajax.reload();
//                }, 5000);
//            } else if (data === "Activity is processed by other user") {
//                toastr.warning('Activity is processed by other user.');
//                setTimeout(function () {
//                    //$('#filesTable').DataTable().ajax.reload();
//                }, 5000);
//            } else if (data === "Please select status") {
//                toastr.error('Please select status.');
//                setTimeout(function () {
//                    //$('#filesTable').DataTable().ajax.reload();
//                }, 5000);
//            } else {
//                setTimeout(function () {
//                    //location.reload();
//                }, 5000);
//            }

//            const statusdata = statuscell.data();
//            const commentdata = commentcell.data();
//            const siInput = $('<input type="datetime-local" class="form-control">').val(sidata);
//            const containerInput = $('<input type="text" class="form-control">').val(containerdata);
//            const statusInput = $(`<select class="form-control" id="status" data-row="${row.StatusId}">
//                                                  <option value="">--select--</option>
//                                                  @foreach(var item in status){
//                                                    <option value="@item.Id">@item.Status</option>
//                                                  }
//                                                </select>`).val(status);
//            const commentInput = $('<input type="text" class="form-control">').val(commentdata);
//            let tallystatusInput = '', tallycommentInput = '', mblstatusInput = '', mblcommentInput = '';

//            if (activityName === "SI To Carrier") {
//                tallystatusInput = $(`<select class="form-control" id="tallystatus" data-row="${row.StatusId}">
//                                                    <option value="">--select--</option>
//                                                    @foreach(var item in status){
//                                                      <option value="@item.Id">@item.Status</option>
//                                                    }
//                                                 </select>`).val(tallySheet);
//                tallycommentInput = $('<input type="text" class="form-control">').val(tallySheetComent);
//                mblstatusInput = $(`<select class="form-control" id="mblstatus" data-row="${row.StatusId}">
//                                                  <option value="">--select--</option>
//                                                  @foreach(var item in status){
//                                                    <option value="@item.Id">@item.Status</option>
//                                                  }
//                                                </select>`).val(mblReview);
//                mblcommentInput = $('<input type="text" class="form-control">').val(mblReviewComment);
//            }

//            sicell.node().innerHTML = '';
//            containercell.node().innerHTML = '';
//            statuscell.node().innerHTML = '';
//            commentcell.node().innerHTML = '';

//            if (activityName === "SI To Carrier") {
//                tallySheetIdcell.node().innerHTML = '';
//                mblReviewIdcell.node().innerHTML = '';
//                tallySheetcommentcell.node().innerHTML = '';
//                mblReviewcommentcell.node().innerHTML = '';
//            }

//            if (siInput.length) {
//                siInput.appendTo(sicell.node());
//            }
//            if (containerInput.length) {
//                containerInput.appendTo(containercell.node());
//            }
//            if (statusInput.length) {
//                statusInput.val(status);
//                statusInput.appendTo(statuscell.node());
//            }
//            if (commentInput.length) {
//                commentInput.appendTo(commentcell.node());
//            }
//            if (tallystatusInput.length) {
//                tallystatusInput.appendTo(tallySheetIdcell.node());
//            }
//            if (tallycommentInput.length) {
//                tallycommentInput.appendTo(tallySheetcommentcell.node());
//            }
//            if (mblstatusInput.length) {
//                mblstatusInput.appendTo(mblReviewIdcell.node());
//            }
//            if (mblcommentInput.length) {
//                mblcommentInput.appendTo(mblReviewcommentcell.node());
//            }
//        },
//        error: function (xhr) {
//            toastr.error('Unable to update. Service error !');
//        }
//    });

//    $(this).removeClass('btn-default edit-btn').addClass('btn-default save-button').html('<i class="fa fa-save" style="color: green;"></i>');
//    $('.edit-btn').not(this).prop('disabled', true);
//    const cancelButton = $('<button class="btn btn-default cancel-btn"><i class="fa fa-times" style="color: red;"></i></button>');
//    cancelButton.insertAfter($(this));
//});


//$('#filesTable').on('click', '.save-button', function () {
//    const row = $(this).closest('tr');
//    const sicell = table.cell(row, 9);
//    const containercell = table.cell(row, 11);
//    const statuscell = table.cell(row, 13);
//    const commentcell = table.cell(row, 14);
//    const si = sicell.node().querySelector('input').value;
//    const containerNo = containercell.node().querySelector('input').value;
//    const activityList = activityIdDataList[0];
//    const activity = activityList.id;
//    const activityName = activityList.nameOfActivity;
//    let tallySheetIdcell, mblReviewIdcell, tallySheetcommentcell, mblReviewcommentcell;
//    let tallySheet, mblReview, tallySheetComent, mblReviewComment;

//    if (activityName === "SI To Carrier") {
//        tallySheetIdcell = table.cell(row, 15);
//        tallySheetcommentcell = table.cell(row, 16);
//        mblReviewIdcell = table.cell(row, 17);
//        mblReviewcommentcell = table.cell(row, 18);

//        tallySheet = tallySheetIdcell.node().querySelector('select').value;
//        mblReview = mblReviewIdcell.node().querySelector('select').value;
//        tallySheetComent = tallySheetcommentcell.node().querySelector('input').value;
//        mblReviewComment = mblReviewcommentcell.node().querySelector('input').value;
//    }

//    const status = statuscell.node().querySelector('select').value;
//    const statusoption = statuscell.node().querySelector('select option:checked');
//    const statusName = statusoption ? statusoption.textContent : "";

//    const comment = commentcell.node().querySelector('input').value;
//    const startDate = $('#dateTime').val();
//    const rowData = table.row(row).data();

//    if (statusName === "" || statusName === undefined || statusName === null) {
//        toastr.warning('Please select status.');
//        return;
//    }

//    if (statusName !== "Completed" && (comment === "" || comment === null)) {
//        toastr.warning('Please enter comment and comment must be 10 characters long.');
//        return;
//    } else if (comment.length < 10 && statusName !== "Completed") {
//        toastr.warning('Comment should be at least 10 characters long.');
//        return;
//    } else if (containerNo.length < 10 && containerNo.length) {
//        toastr.warning('Invalid container number. Correct format is: "ABCD123456"');
//        return;
//    } else if (containerNo.length > 11 && containerNo.length) {
//        toastr.warning('Invalid container number. Correct format is: "ABCD123456"');
//        return;
//    }

//    const FileActivityLogViewModel = {
//        FileId: rowData.id,
//        FileLogId: rowData.fileLogId,
//        ActivityId: activity,
//        StatusId: status,
//        Comment: comment,
//        SI: si,
//        ContainerId: rowData.containerId,
//        ContainerNo: containerNo,
//        StartDate: startDate,
//        UserId: rowData.userId,
//        TallySheetId: tallySheet,
//        MBLReviewId: mblReview,
//        TallySheetComment: tallySheetComent,
//        MBLReviewComment: mblReviewComment,
//        fileComments: fileComments
//    };

//    console.log("Data:" + FileActivityLogViewModel);

//    $.ajax({
//        type: "post",
//        url: AddFileActivitiesUrl,
//        data: {
//            model: FileActivityLogViewModel,
//            button: "Save",
//            statusValue: statusValue,
//            startDateValue: startDateValue,
//            endDateValue: endDateValue,
//            tallySheet: tallySheetIdValue,
//            mblReview: mblReviewIdValue,
//            tallySheetComments: tallySheetCommentValue,
//            mblReviewComments: mblReviewCommentValue
//        },
//        datatype: "json",
//        cache: false,
//        success: function (data) {
//            if (data == "Error while processing the request") {
//                toastr.error('Error while processing the request.');
//                setTimeout(function () {
//                    location.reload();
//                }, 5000);
//            } else if (data == "Please select activitiy") {
//                toastr.error('Please select activity.');
//                setTimeout(function () {
//                    //location.reload();
//                }, 5000);
//            } else if (data == "Please select status") {
//                toastr.error('Please select status.');
//                setTimeout(function () {
//                    //location.reload();
//                }, 5000);
//            } else if (data == "Please complete Tally Sheet and MBL Review activity.") {
//                toastr.error('Please complete Tally Sheet and MBL Review activity.');
//                setTimeout(function () {
//                    //location.reload();
//                }, 5000);
//            } else {
//                toastr.success('File saved.');
//                setTimeout(function () {
//                    sicell.node().contenteditable = false;
//                    containercell.node().contenteditable = false;
//                    statuscell.node().contenteditable = false;
//                    commentcell.node().contenteditable = false;
//                    if (activityName === "SI To Carrier") {
//                        tallySheetIdcell.node().contenteditable = false;
//                        mblReviewIdcell.node().contenteditable = false;
//                        tallySheetcommentcell.node().contenteditable = false;
//                        mblReviewcommentcell.node().contenteditable = false;
//                    }
//                    $('#filesTable').DataTable().ajax.reload();
//                }, 2000);
//            }
//        },
//        error: function (xhr) {
//            toastr.error('Unable to update. Service error!');
//        }
//    });

//    sicell.node().contenteditable = false;
//    containercell.node().contenteditable = false;
//    statuscell.node().contenteditable = false;
//    commentcell.node().contenteditable = false;
//    if (activityName === "SI To Carrier") {
//        tallySheetIdcell.node().contenteditable = false;
//        mblReviewIdcell.node().contenteditable = false;
//        tallySheetcommentcell.node().contenteditable = false;
//        mblReviewcommentcell.node().contenteditable = false;
//    }
//    $(this).removeClass('btn-default save-button').addClass('btn-default edit-btn').html('<i class="fa fa-edit" style="color: green;"></i>');
//    $('.edit-btn').not(this).prop('disabled', false);
//});



//$('#filesTable tbody').on('click', 'td.dt-control', function () {

//    var tr = $(this).closest('tr');
//    var row = table.row(tr);

//    if (row.child.isShown()) {
//        // This row is already open - close it
//        row.child.hide();
//        tr.removeClass('shown');
//    } else {
//        table.rows().every(function () {
//            if (this.child.isShown()) {
//                this.child.hide();
//                $(this.node()).removeClass('shown');
//            }
//        });
//        format(row.child, row.data());
//        tr.addClass('shown');
//    }
//});



//function format(callback, d) {

//    console.log(d);
//    // `d` is the original data object for the row

//    $.ajax({
//        url: GetHblDataUrl,
//        type: "GET",
//        data: {
//            id: d.containerId,

//        },

//        success: function (response) {

//            var tableHTML1 = '<div id="fileactivity" class="table-responsive " style="display: inline-block;"><table class="table table-bordered" width="100%" cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
//            tableHTML1 = tableHTML1 + '<thead class="thead-dark"><tr><th hidden></th><th>Activity</th><th>Status</th><th>User</th><th>Start Date</th><th>End Date</th><th>TotalLBL</th><th>TotalTBL</th><th>TotalHBL</th></tr></thead><tbody>';

//            var tableHTML2 = '<div class="table-responsive " style="display: inline-block;"><table  id="hbldatatable" class="table table-bordered" width="100%" cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
//            tableHTML2 = tableHTML2 + '<thead class="thead-dark"><tr><th hidden></th><th>HBL #</th><th>Customer Name</th><th>Booking #</th></tr></thead><tbody>';

//            if (response.fm.length > 0) {

//                console.log(response.sm);

//                for (var i = 0; i < response.fm.length; i++) {
//                    // Get the current hbl object
//                    var fm = response.fm[i];


//                    // Add a new row to the table for the hbl object
//                    if (i % 2 == 0) {
//                        tableHTML1 += "<tr>";
//                        tableHTML1 += "<td hidden>" + fm.containerId + "</td>";
//                        tableHTML1 += "<td> " + fm.activityId + "</td>";
//                        tableHTML1 += "<td> " + (fm.statusId === null ? "UnAllocated" : fm.statusId) + "</td>";
//                        tableHTML1 += "<td>" + (fm.userId === null ? "" : fm.userId) + "</td>";
//                        tableHTML1 += "<td>" + formatDate(fm.startDate) + "</td>";
//                        tableHTML1 += "<td>" + formatDate(fm.endDate) + "</td>";
//                        tableHTML1 += "<td>" + fm.lbl + "</td>";
//                        tableHTML1 += "<td>" + fm.tbl + "</td>";
//                        tableHTML1 += "<td>" + fm.totalHBL + "</td>";
//                        tableHTML1 += "</tr>";
//                    }
//                    else {
//                        tableHTML1 += "<tr>";
//                        tableHTML1 += "<td hidden>" + fm.containerId + "</td>";
//                        tableHTML1 += "<td> " + fm.activityId + "</td>";
//                        tableHTML1 += "<td> " + (fm.statusId === null ? "UnAllocated" : fm.statusId) + "</td>";
//                        tableHTML1 += "<td>" + (fm.userId === null ? "" : fm.userId) + "</td>";
//                        tableHTML1 += "<td>" + formatDate(fm.startDate) + "</td>";
//                        tableHTML1 += "<td>" + formatDate(fm.endDate) + "</td>";
//                        tableHTML1 += "<td>" + fm.lbl + "</td>";
//                        tableHTML1 += "<td>" + fm.tbl + "</td>";
//                        tableHTML1 += "<td>" + fm.totalHBL + "</td>";
//                        tableHTML1 += "</tr>";
//                    }
//                }
//                tableHTML1 = tableHTML1 + '</tbody></table></div>';
//            }
//            else {
//                var tableHTMLnodata = '<div class="table-responsive " style="display: inline-block;"><table class="table table-bordered" width="100%" cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
//                tableHTMLnodata = tableHTMLnodata + '<thead class="thead-dark"><tr><th hidden></th><th>Activity</th><th>Status</th><th>User</th><th>Start Date</th><th>End Date</th><th>TotalLBL</th><th>TotalTBL</th><th>TotalHBL</th></tr></thead><tbody>';
//                var tableHTML1 = tableHTMLnodata + '<tr align="Center" style="padding:2px"><td colspan="6">No Data to Show</td></tr>';
//                var tableHTML1 = tableHTML1 + '</tbody></table></div>';
//            }

//            if (response.hbl.length > 0) {

//                for (var i = 0; i < response.hbl.length; i++) {
//                    // Get the current hbl object
//                    var hbl = response.hbl[i];

//                    // Add a new row to the table for the hbl object
//                    if (i % 2 == 0) {
//                        tableHTML2 += "<tr onclick = formatHBLActivityData('" + hbl.id + "')>";

//                        tableHTML2 += "<td hidden>" + hbl.id + "</td>";
//                        tableHTML2 += "<td>" + hbl.hblNumber + "</td>";
//                        tableHTML2 += "<td>" + hbl.customerName + "</td>";
//                        tableHTML2 += "<td>" + hbl.booking + "</td>";
//                        tableHTML2 += "</tr>";
//                    }
//                    else {
//                        tableHTML2 += "<tr onclick = formatHBLActivityData('" + hbl.id + "')>";

//                        tableHTML2 += "<td hidden>" + hbl.id + "</td>";
//                        tableHTML2 += "<td>" + hbl.hblNumber + "</td>";
//                        tableHTML2 += "<td>" + hbl.customerName + "</td>";
//                        tableHTML2 += "<td>" + hbl.booking + "</td>";
//                        tableHTML2 += "</tr>";
//                    }
//                }
//                tableHTML2 = tableHTML2 + '</tbody></table></div>';

//            }
//            else {
//                var tableHTMLnodata = '<div class="table-responsive " style="display: inline-block;"><table class="table table-bordered" width="100%" cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
//                tableHTMLnodata = tableHTMLnodata + '<thead class="thead-dark"><tr><th hidden></th><th>HBL #</th><th>Customer Name</th><th>Booking #</th></tr></thead><tbody>';
//                var tableHTML2 = tableHTMLnodata + '<tr align="Center" style="padding:2px"><td colspan="6">No Data to Show</td></tr>';
//                var tableHTML2 = tableHTML2 + '</tbody></table></div>';
//            }

//            // Combine the two table divs into a single HTML string
//            var combinedHTML = '<div class="row"><div class="col-3">' + tableHTML2 + '</div><div class="col-3">' + tableHTML1 + '</div></div>';

//            callback(combinedHTML).show();
//        }

//    });

//}

//$('#search-button').click(function () {
//    $('#filesTable').DataTable().ajax.reload();
//});
//$('#clear-button').click(function () {
//    location.reload();
//});

//function formatDate(data) {
//    if (data != null && data != "") {
//        var date = new Date(data);
//        var month = date.getMonth() + 1;
//        var year = date.getFullYear();
//        var hr = date.getHours();
//        var mn = date.getMinutes();
//        var formattedDate = ((month.toString().length > 1 ? month : "0" + month) + "/"
//            + (date.getDate().toString().length > 1 ? date.getDate() : "0"
//                + date.getDate()) + "/" + date.getFullYear() + " " + (hr.toString().length > 1 ? hr : "0" + hr) + ":" + (mn.toString().length > 1 ? mn : "0" + mn));

//        $('#dateTime').val(formattedDate);
//        return formattedDate;
//    }
//    else {

//        return "";
//    }

//}

//function setFormattedDateTime() {
//    let dateTime = new Date(); // create a new Date object with the current date and time
//    let utcDate = dateTime.getUTCDate();
//    let utcMonth = dateTime.getUTCMonth() + 1; // getMonth() returns 0-11, so add 1 to get the actual month
//    let utcYear = dateTime.getUTCFullYear();
//    let utcHours = dateTime.getUTCHours();
//    let utcMinutes = dateTime.getUTCMinutes();
//    let utcSeconds = dateTime.getUTCSeconds();
//    let formattedDateTime = new Date(Date.UTC(utcYear, utcMonth - 1, utcDate, utcHours, utcMinutes, utcSeconds)).toLocaleString('en-US', {
//        month: '2-digit',
//        day: '2-digit',
//        year: 'numeric',
//        hour: 'numeric',
//        minute: 'numeric',
//        second: 'numeric',
//        hour12: true
//    }); // format the date and time string in the desired format
//    formatDate(formattedDateTime);
//    // Set the formatted date and time value to the dateTime input field
//}


let searchValue = null,
    statusValue = null,
    startDateValue = null,
    endDateValue = null,
    tallySheetIdValue = null,
    mblReviewIdValue = null,
    tallySheetCommentValue = null,
    mblReviewCommentValue = null,
    fileComments = null;
$(document).ready(function () {
    $('.select2').select2();
    getTableData(GetFilesUrl);
    var activityList = activityIdDataList[0];
    var activityId = activityList.id;
    var activity = activityList.nameOfActivity;
    $('#hiddenLabel').text(activity);
    $('#hiddenLabelId').val(activityId);
});

function showInsertActivityPopUp(fileId) {
    $.ajax({
        url: FileActivityUrl + '?Id=' + fileId,
        type: 'GET',
        success: function (data) {
            $('#modal-content').html(data);
            $('#modal-content').modal();
        },
        error: function () {
            alert("There is some problem in the service!")
        }
    });
}

function showCreateFilePopUp() {
    $.ajax({
        url: CreateFileUrl,
        type: 'GET',
        success: function (data) {
            $('#modal-content').html(data);
            $('#modal-content').modal();
            $('#FileNo').on('blur', validateFileNumber);
        },
        error: function () {
            alert("There is some problem in the service!")
        }
    });
}

function showInsertFilePopUp() {
    $('.select2').select2();
    setFormattedDateTime();
    $.ajax({
        url: InsertFileUrl,
        type: 'GET',
        success: function (data) {
            $('#modal-content').html(data);
            $('#modal-content').modal();
            $('.select2').select2();
            $('#countryList').select2({
                placeholder: '-- Select Country --',
            });

            $.getScript('/js/Validation.js', function () {
                // Bind the blur event handlers
                $('#countryList option:selected').on('blur', validateCountry);
                $('#FileNo').on('blur', validateFileNumber);
                $('#ContainerNo').on('blur', validateContainer);
                $('#ETD').on('blur', validateETD);
                $('#ETAPOD').on('blur', validateETAPOD);
                $('#ETA').on('blur', validateETA);
                $('#DraftCutOff').on('blur', validateSICutOff);
                //$('#ATD').on('blur', validateATD);
                var fileNo = $('#FileNo').val();
                if (fileNo != null || fileNo != undefined || fileNo != '') {
                    filenoChange();

                }
                $('#AddContainerButton').on('click', function (event) {
                    addContainer(event);
                });
                $('#SaveContainerButton').on('click', function () {
                    saveContainer();
                });
            });

        },
        error: function () {
            alert("There is some problem in the service!")
        }
    });
}

function InsertFile() {
    const FileActivitiesArray = [];
    const FileActivitiesModel = {
        ActivityId: $('#Activity').val(),
        StatusId: $('#Status').val(),
        Comment: $('#Comment').val()
    };

    FileActivitiesArray.push(FileActivitiesModel);

    const selectedCountry = $('#countryList option:selected').val();
    const fileNo = $('#FileNo').val();
    const etd = $('#ETD').val();
    const etapod = $('#ETAPOD').val();
    const eta = $('#ETA').val();
    const atd = $('#ATD').val();

    if (!selectedCountry || selectedCountry === "none" || selectedCountry === "--Select--") {
        toastr.warning('Please select country');
        return;
    }

    if (!fileNo) {
        toastr.warning('Please select file number');
        return;
    }

    if (!etd) {
        toastr.warning('Please select ETD');
        return;
    }

    if (!etapod) {
        toastr.warning('Please select ETAPOD');
        return;
    }

    if (!eta) {
        toastr.warning('Please select ETA');
        return;
    }

    //if (!atd) {
    //    toastr.warning('Please select ATD');
    //    return;
    //}

    const FileAddActivityLogModel = {
        CountryId: selectedCountry,
        FileNumber: fileNo,
        Container: $('#ContainerNo').val(),
        ETD: etd,
        ETAPOD: etapod,
        ETA: eta,
        SICutOff: $('#DraftCutOff').val(),
        ATD: atd,
        TotalHBL: $('#total').val(),
        FileContact: $('#fileContact').val(),
        ShippingAgent: $('#shippingAgent').val(),
        ShippingLine: $('#shippingLine').val(),
        FileActivities: FileActivitiesArray,
        StartDateTime: $('#dateTime').val()
    };

    console.log(FileAddActivityLogModel);
    $.ajax({

        type: "post",
        url: AddFileNewActivityUrl,
        data: FileAddActivityLogModel,
        datatype: "json",
        cache: false,
        success: function (data) {

            if (data == "Error while processing the request") {
                toastr.error('Error while processing the request.');
            }
            else if (data == "Duplicate") {
                toastr.warning('Activity with same name already exists');
            }
            else {
                toastr.success('File Inserted Successfully..!!');
                setTimeout(function () {
                    //location.reload();
                    $('#modal-content').modal('hide');
                    $("#modal-content").hide();
                    $('#filesTable').DataTable().ajax.reload();
                }, 5000);
            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error !');
        }
    });
}

function saveFile() {

    var FileAddActivityLogModel = {
        CountryId: $('#countryList').val(),
        FileNumber: $('#FileNo').val(),
        ETD: $('#ETD').val(),
        DraftCutOff: $('#DraftCutOff').val(),
    }
    console.log(FileAddActivityLogModel);
    $.ajax({

        type: "post",
        url: '@Url.Action("AddFileNewActivity","User")',
        data: FileAddActivityLogModel,
        datatype: "json",
        cache: false,
        success: function (data) {

            if (data == "Error while processing the request") {
                toastr.error('Error while processing the request.');
            }
            else if (data == "Duplicate") {
                toastr.warning('Activity with same name already exists');
            }
            else {
                toastr.success('File Inserted Successfully..!!');
                $("#modal-content").hide();
                $('#filesTable').DataTable().ajax.reload();

            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error !');
        }
    });
}

function saveFileActivity() {
    var FileActivityLogModel = {
        FileId: document.getElementById("containerNo").innerHTML.trim(),
        ActivityId: $('#Activity').val(),
        StatusId: $('#Status').val(),
        Comment: $('#Comment').val(),
        UserId: $('#Status').val(),
    }
    console.log(FileActivityLogModel);
    $.ajax({

        type: "post",
        url: '@Url.Action("AddActivity","User")',
        data: FileActivityLogModel,
        datatype: "json",
        cache: false,
        success: function (data) {

            if (data == "Error while processing the request") {
                toastr.error('Error while processing the request.');
            }
            else if (data == "Duplicate") {
                toastr.warning('Activity with same name already exists');
            }
            else if (data == "Status Update Successfully.") {
                toastr.success('Activity Status Update Successfully..!!');
            }
            else {
                toastr.success('Activity Inserted Successfully..!!');
                showInsertActivityPopUp(data);

            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error !');
        }

    });


}

function showCreateHBLPopUp() {
    $('.select2').select2();
    setFormattedDateTime();
    $.ajax({
        url: CreateHBLUrl,
        type: 'GET',
        success: function (data) {
            $('#modal-content').html(data);
            $('#modal-content').modal();
            $('.select2').select2();
            $.getScript('/js/Validation.js', function () {
                // Bind the blur event handlers
                $('#HBLFileNo').on('blur', validateFileNumber);
                $('#Container').on('blur', validateContainer);
                $('#Comment').on('blur', validateComment);
                //$('#HBLStatus').on('blur', validateStatus);
                $('#HBLNo').on('blur', validateHBL);
                var fileNo = $('#HBLFileNo').val();
                if (fileNo != null || fileNo != undefined || fileNo != '') {
                    fileChange();

                }
                $('#AddContainerButton').on('click', function (event) {
                    addContainer(event);
                });
                $('#SaveContainerButton').on('click', function () {
                    saveContainer();
                });
            });

        },
        error: function () {
            alert("There is some problem in the service!")
        }
    });
}

function saveHBL() {
    const HBLActivitiesArray = [];
    const HBLActivitiesModel = {
        ActivityId: $('#HBLActivity').val(),
        StatusId: $('#HBLStatus').val(),
        Comment: $('#Comment').val()
    };

    HBLActivitiesArray.push(HBLActivitiesModel);

    const HBLFileNo = $('#HBLFileNo').val();
    const HBLNo = $('#HBLNo').val();
    const HBLActivitySelected = $('#HBLActivity option:selected').val();
    const HBLStatusSelected = $('#HBLStatus option:selected').val();

    if (!HBLFileNo) {
        toastr.warning('Please enter file number');
        return;
    }
    if (!HBLNo) {
        toastr.warning('Please enter HBL number');
        return;
    }
    if (!HBLActivitySelected || HBLActivitySelected === 'none') {
        toastr.warning('Please select an activity');
        return;
    }
    if (!HBLStatusSelected || HBLStatusSelected === 'none') {
        toastr.warning('Please select a status');
        return;
    }

    const HBLUserViewModel = {
        CountryId: $('#HBLcountryLists').val(),
        FileNo: HBLFileNo,
        Container: $('#Container').val(),
        BookingNo: $('#BookingNo').val(),
        HBL_No: HBLNo,
        CustomerName: $('#Customer').val(),
        StartDateTime: $('#dateTime').val(),
        HBLActivities: HBLActivitiesArray
    };

    console.log(HBLActivitiesArray);
    console.log(HBLUserViewModel);

    $.ajax({
        type: 'post',
        url: AddNewHBLActivityUrl,
        data: HBLUserViewModel,
        datatype: 'json',
        cache: false,
        success: function (data) {
            if (data == 'Error while processing the request') {
                toastr.error('Error while processing the request.');
            } else if (data == 'Duplicate') {
                toastr.warning('Activity with the same name already exists');
            } else if (data == 'File does not exist, first insert file') {
                toastr.warning('File does not exist, first insert the file.');
            } else if (data == 'HBL no is already added') {
                toastr.warning('HBL no is already added.');
            } else {
                toastr.success('HBL Inserted Successfully..!!');
                setTimeout(function () {
                    $('#modal-content').modal('hide');
                    $('#modal-content').hide();
                    $('#hblTable').DataTable().ajax.reload();
                }, 5000);
            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error !');
        }
    });
}

function fileChange() {

    const fileNo = $('#HBLFileNo').val();

    $.ajax({
        type: "GET",
        url: GetContainerUrl,
        data: {
            fileNo: fileNo
        },
        dataType: "json",
        cache: false,
        success: function (data) {
            if (data.success === "Error while processing the request") {
                toastr.error('Error while processing the request.');
            } else if (data === "Duplicate") {
                toastr.warning('Activity with the same name already exists');
            } else if (data === "File does not exist first insert file") {
                toastr.warning('File does not exist first insert file.');
            } else if (data === "HBL no is already added") {
                toastr.warning('HBL no is already added.');
            } else {
                const containerSelect = $('#Container');
                containerSelect.empty();
                containerSelect.append($('<option>').val('').text('-- Select Container --'));
                $.each(data.containerList, function (index, container) {
                    containerSelect.append($('<option>').val(container.id).text(container.containerNo));
                });
                // Refresh the select2 control
                containerSelect.trigger('change');
            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error !');
        }
    });

}

function filenoChange() {

    const fileNo = $('#FileNo').val();
    console.log("fileNo", fileNo);

    $.ajax({
        type: "GET",
        url: GetContainerUrl,
        data: { fileNo: fileNo },
        dataType: "json",
        cache: false,
        success: function (data) {
            if (data.success === "Error while processing the request") {
                toastr.error('Error while processing the request.');
            } else if (data === "Duplicate") {
                toastr.warning('Activity with the same name already exists.');
            } else if (data === "File does not exist, first insert file") {
                toastr.warning('File does not exist, first insert file.');
            } else if (data === "HBL no is already added") {
                toastr.warning('HBL no is already added.');
            } else {
                const containerSelect = $('#Container');
                containerSelect.empty();
                containerSelect.append($('<option>').val('').text('-- Select Container --'));
                $.each(data.containerList, function (index, container) {
                    containerSelect.append($('<option>').val(container.id).text(container.containerNo));
                });
                // Refresh the select2 control
                containerSelect.trigger('change');
            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error !');
        }
    });

}

function addContainer(event) {
    event.preventDefault();
    event.stopPropagation();

    $('#AddContainerButton').hide();
    $('#AddContainerInputSection').show();
}

function saveContainer() {
    var containerInputValue = $('#ContainerInput').val();
    if (containerInputValue) {
        var containerSelect = $('#Container');
        var newOption = $('<option>').val(containerInputValue).text(containerInputValue);
        containerSelect.append(newOption);
        containerSelect.val(containerInputValue).trigger('change');
        $('#ContainerInput').val('');
        $('#AddContainerInputSection').hide();
        $('#AddContainerButton').show();
    }

}

function getTableData(GetFilesUrl) {
    var ele = $(".container-fluid");
    console.log(window.screen.height);
    console.log(ele[0].getBoundingClientRect().bottom);
    console.log(window.screen.height - ele[0].getBoundingClientRect().bottom) - 80;
    var avail_height = (window.screen.height - ele[0].getBoundingClientRect().bottom);
    var activityList = activityIdDataList[0];
    var activityName = activityList.nameOfActivity;
    var activityType = activityList.activityType;
    if (activityName === "SI To Carrier") {
        table = $('#filesTable').DataTable({
            paging: true,
            scrollX: true,
            scroller: true,
            processing: true,
            serverSide: true,
            scrollY: avail_height < 400 ? avail_height - 120 : avail_height - 140,
            info: true,
            orderCellsTop: true,
            dom: 'lfrtip',
            fixedColumns: {
                leftColumns: 4
            },
            "ajax": {
                "url": GetFilesUrl,
                "type": "POST",
                "data": function (d) {
                    d.fileNumber = $('#FileNumber').val();
                    d.activity = activityName;
                    d.search = searchValue;
                    d.type = activityType;

                }
            },
            "columns": [
                {
                    "data": null
                },
                { "data": "id", "name": "id", "label": "Id", "visible": false },
                {
                    "data": "enterDate", "name": "enterDate", "label": "Received Date", "autoWidth": true, render: function (data, type, full, meta) {
                        return formatDate(data)
                    }
                },
                { "data": "fileNumber", "name": "fileNumber", "label": "File#", "autoWidth": true },
                { "data": "pod", "name": "pod", "label": "POD", "autoWidth": true },
                {
                    "data": "etd", "name": "etd", "label": "ETD", "autoWidth": true, render: function (data, type, full, meta) {
                        return formatDate(data)
                    }
                },
                {
                    "data": "etapod", "name": "etapod", "label": "ETAPOD", "autoWidth": true, render: function (data, type, full, meta) {
                        return formatDate(data)
                    }
                },
                {
                    "data": "eta", "name": "eta", "label": "ETA", "autoWidth": true, render: function (data, type, full, meta) {
                        return formatDate(data)
                    }
                },
                {
                    "data": "atd", "name": "atd", "label": "ATD", "autoWidth": true, render: function (data, type, full, meta) {
                        return formatDate(data)
                    }
                },
                {
                    "data": "siCutOff", "name": "siCutOff", "label": "SI Cut Off", "autoWidth": true, contenteditable: true, render: function (data, type, full, meta) {
                        return formatDate(data)
                    }
                },
                { "data": "fileContact", "name": "fileContact", "label": "File Contact", "autoWidth": true },
                { "data": "containerNo", "name": "containerNo", "label": "Container#", "autoWidth": true, contenteditable: true },
                { "data": "totalHBL", "name": "totalHBL", "label": "Total HBL", "autoWidth": true },
                { "data": "statusId", "name": "statusId", "label": "Status", "autoWidth": true, contenteditable: true },
                { "data": "comment", "name": "comment", "label": "Comment", contenteditable: true },
                { "data": "tallySheetId", "name": "tallySheetId", "label": "Tally Sheet Status", contenteditable: true, "visible": false, visible: activityName === "SI To Carrier" },
                { "data": "tallySheetComment", "name": "tallySheetComment", "label": "Tally Sheet Comment", contenteditable: true, "visible": false, visible: activityName === "SI To Carrier" },
                { "data": "mblReviewId", "name": "mblReviewId", "label": "MBL Review Status", contenteditable: true, "visible": false, visible: activityName === "SI To Carrier" },
                { "data": "mblReviewComment", "name": "mblReviewComment", "label": "MBL Review Comment", contenteditable: true, "visible": false, visible: activityName === "SI To Carrier" },
                {
                    "data": null, "autoWidth": true,
                    "render": function (data, type, row, meta) {
                        if (data.userId === data.currentUser || data.userId === null || data.userId === "") {
                            return '<button type="button" class=" edit-btn btn btn-default mr-1"><i class="fa fa-edit" style="color: green;"></i></button>'
                        }
                        else {
                            return '';
                        }


                    }

                },

            ],
            "columnDefs":
                [
                    {
                        className: 'dt-control',
                        orderable: false,
                        data: null,
                        defaultContent: '',
                        targets: 0,
                        width: "1%"
                    },
                    { 'visible': false, 'targets': [1] },
                ],
            "createdRow": function (row, data, dataIndex) {
                if (data.userId !== null && data.statusId === "Pending") {
                    if (data.userId == data.currentUser) {
                        $(row).addClass('highlight-color');
                    }
                }
            }

        });

    }
    else {
        table = $('#filesTable').DataTable({
            paging: true,
            scrollX: true,
            scroller: true,
            processing: true,
            serverSide: true,
            scrollY: avail_height < 400 ? avail_height - 120 : avail_height - 140,
            info: true,
            orderCellsTop: true,
            dom: 'lfrtip',  
            fixedColumns: {
                leftColumns: 4
            },
            "ajax": {
                "url": GetFilesUrl,
                "type": "POST",
                "data": function (d) {
                    d.fileNumber = $('#FileNumber').val();
                    d.activity = activityName;
                    d.search = searchValue;
                    d.type = activityType;

                }
            },
            "columns": [
                {
                    "data": null
                },
                { "data": "id", "name": "id", "label": "Id", "visible": false },
                {
                    "data": "enterDate", "name": "enterDate", "label": "Received Date", /* "autoWidth": true,*/ render: function (data, type, full, meta) {
                        return formatDate(data)
                    }
                },
                { "data": "fileNumber", "name": "fileNumber", "label": "File#" /*, "autoWidth": true*/ },
                { "data": "pod", "name": "pod", "label": "POD" /*, "autoWidth": true */},
                {
                    "data": "etd", "name": "etd", "label": "ETD", /*, "autoWidth": true,*/ render: function (data, type, full, meta) {
                        return formatDate(data)
                    }
                },
                {
                    "data": "etapod", "name": "etapod", "label": "ETAPOD", /*"autoWidth": true,*/ render: function (data, type, full, meta) {
                        return formatDate(data)
                    }
                },
                {
                    "data": "eta", "name": "eta", "label": "ETA", /*"autoWidth": true,*/ render: function (data, type, full, meta) {
                        return formatDate(data)
                    }
                },
                {
                    "data": "atd", "name": "atd", "label": "ATD",/* "autoWidth": true,*/ render: function (data, type, full, meta) {
                        return formatDate(data)
                    }
                },
                {
                    "data": "siCutOff", "name": "siCutOff", "label": "SI Cut Off", /*"autoWidth": true,*/ contenteditable: true, render: function (data, type, full, meta) {
                        return formatDate(data)
                    }
                },
                { "data": "fileContact", "name": "fileContact", "label": "File Contact", /*"autoWidth": true*/ },
                { "data": "containerNo", "name": "containerNo", "label": "Container#", /*"autoWidth": true,*/ contenteditable: true },
                { "data": "totalHBL", "name": "totalHBL", "label": "Total HBL", /*"autoWidth": true */},
                { "data": "statusId", "name": "statusId", "label": "Status", /*"autoWidth": true,*/ contenteditable: true },
                { "data": "comment", "name": "comment", "label": "Comment", contenteditable: true },
                {
                    "data": null, /* "autoWidth": true,*/
                    "render": function (data, type, row, meta) {
                        if (data.userId === data.currentUser || data.userId === null || data.userId === "") {
                            return '<button type="button" class=" edit-btn btn btn-default mr-1"><i class="fa fa-edit" style="color: green;"></i></button>'
                        }
                        else {
                            return '';
                        }


                    }

                },

            ],
            "columnDefs":
                [
                    {
                        className: 'dt-control',
                        orderable: false,
                        data: null,
                        defaultContent: '',
                        targets: 0,
                        width: "1%"
                    },
                    { 'visible': false, 'targets': [1] },

                ],
            "createdRow": function (row, data, dataIndex) {
                if (data.userId !== null && data.statusId === "Pending") {
                    if (data.userId == data.currentUser) {
                        $(row).addClass('highlight-color');
                    }
                }
            }

        });

    }
}

$('#search-row input').on('keyup change', function () {
    table.settings()[0].oFeatures.bServerSide = false; // set serverSide back to false
    var i = $(this).parent().index() + 1;
    var searchstring = this.value.toString().trim();
    table.column(i).search(searchstring).draw();
    table.settings()[0].oFeatures.bServerSide = true; // set serverSide back to true

});

$('#filesTable').on('click', '.cancel-btn', function () {
    const row = $(this).closest('tr');
    const sicell = table.cell(row, 9);
    const containercell = table.cell(row, 11);
    const statuscell = table.cell(row, 13);
    const commentcell = table.cell(row, 14);
    const si = sicell.node().querySelector('input').value;
    const containerNo = containercell.node().querySelector('input').value;
    const activityList = activityIdDataList[0];
    const activity = activityList.id;
    const activityName = activityList.nameOfActivity;

    let tallySheetIdcell, mblReviewIdcell, tallySheetcommentcell, mblReviewcommentcell;
    let tallySheet, mblReview, tallySheetComment, mblReviewComment;

    if (activityName === "SI To Carrier") {
        tallySheetIdcell = table.cell(row, 15);
        tallySheetcommentcell = table.cell(row, 16);
        mblReviewIdcell = table.cell(row, 17);
        mblReviewcommentcell = table.cell(row, 18);

        tallySheet = tallySheetIdcell.node().querySelector('select').value;
        mblReview = mblReviewIdcell.node().querySelector('select').value;
        tallySheetComment = tallySheetcommentcell.node().querySelector('input').value;
        mblReviewComment = mblReviewcommentcell.node().querySelector('input').value;
    }

    const status = statuscell.node().querySelector('select').value;
    const comment = commentcell.node().querySelector('input').value;
    const startDate = $('#dateTime').val();
    const rowData = table.row(row).data();

    const FileActivityLogViewModel = {
        FileId: rowData.id,
        ActivityId: activity,
        StatusId: status,
        Comment: comment,
        SI: si,
        ContainerId: rowData.containerId,
        ContainerNo: containerNo,
        StartDate: startDate,
        UserId: rowData.userId,
        TallySheetId: tallySheet,
        MBLReviewId: mblReview,
        TallySheetComment: tallySheetComment,
        MBLReviewComment: mblReviewComment,
    };

    $.ajax({
        type: "post",
        url: AddFileActivitiesUrl,
        data: {
            model: FileActivityLogViewModel,
            button: "Cancel",
            statusValue: statusValue,
            startDateValue: startDateValue,
            endDateValue: endDateValue,
            tallySheet: tallySheetIdValue,
            mblReview: mblReviewIdValue,
            tallySheetComments: tallySheetCommentValue,
            mblReviewComments: mblReviewCommentValue,
            fileComments: fileComments
        },
        datatype: "json",
        cache: false,
        success: function (data) {
            if (data === "Error while processing the request") {
                toastr.error('Error while processing the request.');
                setTimeout(function () {
                    $('#filesTable').DataTable().ajax.reload();
                }, 2000);
            } else if (data === "Please select activitiy" || data === "Please select status") {
                setTimeout(function () {
                    $('#filesTable').DataTable().ajax.reload();
                }, 2000);
            } else {
                sicell.node().contenteditable = false;
                containercell.node().contenteditable = false;
                statuscell.node().contenteditable = false;
                commentcell.node().contenteditable = false;
                if (activityName === "SI To Carrier") {
                    tallySheetIdcell.node().contenteditable = false;
                    mblReviewIdcell.node().contenteditable = false;
                    tallySheetcommentcell.node().contenteditable = false;
                    mblReviewcommentcell.node().contenteditable = false;
                }
                setTimeout(function () {
                    $('#filesTable').DataTable().ajax.reload();
                }, 2000);
            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error !');
            $('#filesTable').DataTable().ajax.reload();
        }
    });
    sicell.node().contenteditable = false;
    containercell.node().contenteditable = false;
    statuscell.node().contenteditable = false;
    commentcell.node().contenteditable = false;
    if (activityName === "SI To Carrier") {
        tallySheetIdcell.node().contenteditable = false;
        mblReviewIdcell.node().contenteditable = false;
        tallySheetcommentcell.node().contenteditable = false;
        mblReviewcommentcell.node().contenteditable = false;
    }
    $(this).siblings('.cancel-btn').remove(); // Remove the cancel button
    $(this).siblings('.save-button').remove(); // Remove the save button
    $(this).removeClass().addClass('btn btn-default edit-btn').html('<i class="fa fa-edit" style="color: green;"></i>');
    $('.edit-btn').not(this).prop('disabled', false);
});


$('#filesTable').on('click', '.edit-btn', function () {
    setFormattedDateTime();
    const row = $(this).closest('tr');
    const sicell = table.cell(row, 9);
    const containercell = table.cell(row, 11);
    const statuscell = table.cell(row, 13);
    const commentcell = table.cell(row, 14);
    const sidata = sicell.data();
    const containerdata = containercell.data();
    const comment = commentcell.data();
    const status = statuscell.data();
    statusValue = status;
    startDateValue = $('#dateTime').val();
    const rowData = table.row(row).data();
    endDateValue = rowData.endDate;
    fileComments = rowData.comment;
    const activityList = activityIdDataList[0];
    const activity = activityList.id;
    const activityName = activityList.nameOfActivity;
    let tallySheetIdcell, tallySheetcommentcell, mblReviewIdcell, mblReviewcommentcell,
        tallySheet, mblReview, tallySheetComent, mblReviewComment;

    if (activityName === "SI To Carrier") {
        tallySheetIdcell = table.cell(row, 15);
        tallySheetcommentcell = table.cell(row, 16);
        mblReviewIdcell = table.cell(row, 17);
        mblReviewcommentcell = table.cell(row, 18);

        tallySheet = tallySheetIdcell.data();
        mblReview = mblReviewIdcell.data();
        tallySheetComent = tallySheetcommentcell.data();
        mblReviewComment = mblReviewcommentcell.data();

        tallySheetIdValue = rowData.tallySheetId;
        mblReviewIdValue = rowData.mblReviewId;
        tallySheetCommentValue = rowData.tallySheetComment;
        mblReviewCommentValue = rowData.mblReviewComment;
    }

    const startDate = $('#dateTime').val();
    const FileActivityLogViewModel = {
        FileId: rowData.id,
        ActivityId: activity,
        StatusId: status,
        Comment: comment,
        SI: sidata,
        ContainerId: rowData.containerId,
        StartDate: startDate,
        ContainerNo: containerdata,
        UserId: rowData.userId,
        TallySheetId: tallySheet,
        MBLReviewId: mblReview,
        TallySheetComment: tallySheetComent,
        MBLReviewComment: mblReviewComment,
    };

    console.log("Data:" + FileActivityLogViewModel);

    $.ajax({
        type: "post",
        url: AddFileActivitiesUrl,
        data: {
            model: FileActivityLogViewModel,
            button: "Edit",
            statusValue: statusValue,
            startDateValue: startDateValue,
            endDateValue: endDateValue,
            tallySheet: tallySheetIdValue,
            mblReview: mblReviewIdValue,
            tallySheetComments: tallySheetCommentValue,
            mblReviewComments: mblReviewCommentValue,
            fileComments: fileComments
        },
        datatype: "json",
        cache: false,
        success: function (data) {

            if (data == "Error while processing the request") {
                toastr.error('Error while processing the request.');
                setTimeout(function () {
                    //location.reload();
                    location.reload();
                }, 5000);
            }
            else if (data == "Please select activitiy") {
                toastr.error('Please select activitiy.');
                setTimeout(function () {
                    //location.reload();
                    $('#filesTable').DataTable().ajax.reload();
                }, 5000);
            }
            else if (data == "Activity is processed by other user") {
                toastr.warning('Activity is processed by other user.');
                setTimeout(function () {
                    //location.reload();
                    $('#filesTable').DataTable().ajax.reload();
                }, 5000);
            }
            else if (data == "Please select status") {
                toastr.error('Please select status.');
                setTimeout(function () {
                    //location.reload();
                    $('#filesTable').DataTable().ajax.reload();
                }, 5000);
            }
            else {
                setTimeout(function () {
                    //location.reload();
                }, 5000);
                var statusdata = statuscell.data();
                var commentdata = commentcell.data();
                var siInput = $('<input type="datetime-local" class="form-control">').val(sidata);
                var containerInput = $('<input type="text" class="form-control">').val(containerdata);
                //var statusInput = $('<select class="form-control" id="status" data-row"' + row.StatusId + '"><option value="">--select--</option>@foreach(var item in statusDataList){<option value="@item.Id">@item.Status</option>}</select>').val(status);
                var statusInput = $('<select class="form-control" id="status" data-row="' + row.StatusId + '"><option value="">--select--</option></select>').val(status);

                $.each(statusDataList, function (index, item) {
                    statusInput.append($('<option></option>').val(item.id).text(item.status));
                });
                var commentInput = $('<input type="text" class="form-control">').val(commentdata);
                var tallystatusInput = '';
                var tallycommentInput = '';
                var mblstatusInput = '';
                var mblcommentInput = '';
                if (activityName === "SI To Carrier") {
                    tallystatusInput = $('<select class="form-control" id="status" data-row="' + row.StatusId + '"><option value="">--select--</option></select>').val(tallySheet);
                    $.each(statusDataList, function (index, item) {
                        tallystatusInput.append($('<option></option>').val(item.id).text(item.status));
                    });
                    tallycommentInput = $('<input type="text" class="form-control">').val(tallySheetComent);
                    mblstatusInput = $('<select class="form-control" id="status" data-row="' + row.StatusId + '"><option value="">--select--</option></select>').val(mblReview);
                    $.each(statusDataList, function (index, item) {
                        mblstatusInput.append($('<option></option>').val(item.id).text(item.status));
                    });
                    mblcommentInput = $('<input type="text" class="form-control">').val(mblReviewComment);
                }
                sicell.node().innerHTML = '';
                containercell.node().innerHTML = '';
                statuscell.node().innerHTML = '';
                commentcell.node().innerHTML = '';
                if (activityName === "SI To Carrier") {
                    tallySheetIdcell.node().innerHTML = '';
                    mblReviewIdcell.node().innerHTML = '';
                    tallySheetcommentcell.node().innerHTML = '';
                    mblReviewcommentcell.node().innerHTML = '';
                }

                if (siInput.length) {
                    siInput.appendTo(sicell.node());
                }
                if (containerInput.length) {
                    containerInput.appendTo(containercell.node());
                }
                if (statusInput.length) {
                    statusInput.val(status);
                    statusInput.appendTo(statuscell.node());
                }
                if (commentInput.length) {
                    commentInput.appendTo(commentcell.node());
                }
                if (tallystatusInput.length) {
                    tallystatusInput.appendTo(tallySheetIdcell.node());
                }
                if (tallycommentInput.length) {
                    tallycommentInput.appendTo(tallySheetcommentcell.node());
                }
                if (mblstatusInput.length) {
                    mblstatusInput.appendTo(mblReviewIdcell.node());
                }
                if (mblcommentInput.length) {
                    mblcommentInput.appendTo(mblReviewcommentcell.node());
                }


            }
        },
        error: function (xhr) {
            toastr.error('Unable to update. Service error !');
        }
    });

    $(this).removeClass('btn-default edit-btn').addClass('btn-default save-button').html('<i class="fa fa-save" style="color: green;"></i>');
    $('.edit-btn').not(this).prop('disabled', true);
    var cancelButton = $('<button class="btn btn-default cancel-btn"><i class="fa fa-times" style="color: red;"></i></button>');
    cancelButton.insertAfter($(this));
});

$('#filesTable').on('click', '.save-button', function () {
    const row = $(this).closest('tr');
    const sicell = table.cell(row, 9);
    const containercell = table.cell(row, 11);
    const statuscell = table.cell(row, 13);
    const commentcell = table.cell(row, 14);
    const si = sicell.node().querySelector('input').value;
    const containerNo = containercell.node().querySelector('input').value;
    const activityList = activityIdDataList[0];
    const activity = activityList.id;
    const activityName = activityList.nameOfActivity;
    let tallySheetIdcell, mblReviewIdcell, tallySheetcommentcell, mblReviewcommentcell;
    let tallySheet, mblReview, tallySheetComent, mblReviewComment;

    if (activityName === "SI To Carrier") {
        tallySheetIdcell = table.cell(row, 15);
        tallySheetcommentcell = table.cell(row, 16);
        mblReviewIdcell = table.cell(row, 17);
        mblReviewcommentcell = table.cell(row, 18);

        tallySheet = tallySheetIdcell.node().querySelector('select').value;
        mblReview = mblReviewIdcell.node().querySelector('select').value;
        tallySheetComent = tallySheetcommentcell.node().querySelector('input').value;
        mblReviewComment = mblReviewcommentcell.node().querySelector('input').value;
    }

    const status = statuscell.node().querySelector('select').value;
    const statusoption = statuscell.node().querySelector('select option:checked');
    const statusName = statusoption ? statusoption.textContent : "";

    const comment = commentcell.node().querySelector('input').value;
    const startDate = $('#dateTime').val();
    const rowData = table.row(row).data();

    if (statusName === "" || statusName === undefined || statusName === null) {
        toastr.warning('Please select status.');
        return;
    }

    if (statusName !== "Completed" && (comment === "" || comment === null)) {
        toastr.warning('Please enter comment and comment must be 10 characters long.');
        return;
    } else if (comment.length < 10 && statusName !== "Completed") {
        toastr.warning('Comment should be at least 10 characters long.');
        return;
    } else if (containerNo.length < 10 && containerNo.length) {
        toastr.warning('Invalid container number. Correct format is: "ABCD123456"');
        return;
    } else if (containerNo.length > 11 && containerNo.length) {
        toastr.warning('Invalid container number. Correct format is: "ABCD123456"');
        return;
    }

    const FileActivityLogViewModel = {
        FileId: rowData.id,
        FileLogId: rowData.fileLogId,
        ActivityId: activity,
        StatusId: status,
        Comment: comment,
        SI: si,
        ContainerId: rowData.containerId,
        ContainerNo: containerNo,
        StartDate: startDate,
        UserId: rowData.userId,
        TallySheetId: tallySheet,
        MBLReviewId: mblReview,
        TallySheetComment: tallySheetComent,
        MBLReviewComment: mblReviewComment,
        fileComments: fileComments
    };
    console.log("Data:" + FileActivityLogViewModel);

        $.ajax({
            type: "post",
            url: AddFileActivitiesUrl,
            data: {
                model: FileActivityLogViewModel,
                button: "Save",
                statusValue: statusValue,
                startDateValue: startDateValue,
                endDateValue: endDateValue,
                tallySheet: tallySheetIdValue,
                mblReview: mblReviewIdValue,
                tallySheetComments: tallySheetCommentValue,
                mblReviewComments: mblReviewCommentValue
            },
            datatype: "json",
            cache: false,
            success: function (data) {

                if (data == "Error while processing the request") {
                    toastr.error('Error while processing the request.');
                    setTimeout(function () {
                        location.reload();

                    }, 5000);
                }
                else if (data == "Please select activitiy") {
                    toastr.warning('Please select activitiy.');
                    setTimeout(function () {
                        $('#filesTable').DataTable().ajax.reload();
                    }, 5000);
                }
                else if (data == "Please select status") {
                    toastr.warning('Please select status.');
                    setTimeout(function () {
                        //location.reload();
                        $('#filesTable').DataTable().ajax.reload();
                    }, 5000);
                }
                else if (data == "Please complete Tally Sheet and MBL Review activity.") {
                    toastr.warning('Please complete Tally Sheet and MBL Review activity.');
                    setTimeout(function () {
                        //location.reload();
                        $('#filesTable').DataTable().ajax.reload();
                    }, 5000);
                }
                else {
                    toastr.success('File saved.');
                    sicell.node().contenteditable = false;
                    containercell.node().contenteditable = false;
                    statuscell.node().contenteditable = false;
                    commentcell.node().contenteditable = false;
                    if (activityName === "SI To Carrier") {
                        tallySheetIdcell.node().contenteditable = false;
                        mblReviewIdcell.node().contenteditable = false;
                        tallySheetcommentcell.node().contenteditable = false;
                        mblReviewcommentcell.node().contenteditable = false;
                    }
                    setTimeout(function () {
                        $('#filesTable').DataTable().ajax.reload();
                    }, 2000);

                }
            },
            error: function (xhr) {
                toastr.error('Unable to update. Service error !');
            }
        });
        sicell.node().contenteditable = false;
        containercell.node().contenteditable = false;
        statuscell.node().contenteditable = false;
        commentcell.node().contenteditable = false;
        if (activityName === "SI To Carrier") {
            tallySheetIdcell.node().contenteditable = false;
            mblReviewIdcell.node().contenteditable = false;
            tallySheetcommentcell.node().contenteditable = false;
            mblReviewcommentcell.node().contenteditable = false;
        }
        $(this).removeClass('btn-default save-button').addClass('btn-default edit-btn').html('<i class="fa fa-edit" style="color: green;"></i>');
        $('.edit-btn').not(this).prop('disabled', false);
    

});


$('#filesTable tbody').on('click', 'td.dt-control', function () {

    var tr = $(this).closest('tr');
    var row = table.row(tr);

    if (row.child.isShown()) {
        // This row is already open - close it
        row.child.hide();
        tr.removeClass('shown');
    } else {
        table.rows().every(function () {
            if (this.child.isShown()) {
                this.child.hide();
                $(this.node()).removeClass('shown');
            }
        });
        format(row.child, row.data());
        tr.addClass('shown');
    }
});



function format(callback, d) {

    console.log(d);
    // `d` is the original data object for the row

    $.ajax({
        url: GetHblDataUrl,
        type: "GET",
        data: {
            id: d.containerId,

        },

        success: function (response) {

            var tableHTML1 = '<div id="fileactivity" class="table-responsive " style="display: inline-block;"><table class="table table-bordered" width="100%" cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
            tableHTML1 = tableHTML1 + '<thead class="thead-dark"><tr><th hidden></th><th>Activity</th><th>Status</th><th>User</th><th>Start Date</th><th>End Date</th><th>TotalLBL</th><th>TotalTBL</th><th>TotalHBL</th></tr></thead><tbody>';

            var tableHTML2 = '<div class="table-responsive " style="display: inline-block;"><table  id="hbldatatable" class="table table-bordered" width="100%" cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
            tableHTML2 = tableHTML2 + '<thead class="thead-dark"><tr><th hidden></th><th>HBL #</th><th>Customer Name</th><th>Booking #</th></tr></thead><tbody>';

            if (response.fm.length > 0) {

                console.log(response.sm);

                for (var i = 0; i < response.fm.length; i++) {
                    // Get the current hbl object
                    var fm = response.fm[i];


                    // Add a new row to the table for the hbl object
                    if (i % 2 == 0) {
                        tableHTML1 += "<tr>";
                        tableHTML1 += "<td hidden>" + fm.containerId + "</td>";
                        tableHTML1 += "<td> " + fm.activityId + "</td>";
                        tableHTML1 += "<td> " + (fm.statusId === null ? "UnAllocated" : fm.statusId) + "</td>";
                        tableHTML1 += "<td>" + (fm.userId === null ? "" : fm.userId) + "</td>";
                        tableHTML1 += "<td>" + formatDate(fm.startDate) + "</td>";
                        tableHTML1 += "<td>" + formatDate(fm.endDate) + "</td>";
                        tableHTML1 += "<td>" + fm.lbl + "</td>";
                        tableHTML1 += "<td>" + fm.tbl + "</td>";
                        tableHTML1 += "<td>" + fm.totalHBL + "</td>";
                        tableHTML1 += "</tr>";
                    }
                    else {
                        tableHTML1 += "<tr>";
                        tableHTML1 += "<td hidden>" + fm.containerId + "</td>";
                        tableHTML1 += "<td> " + fm.activityId + "</td>";
                        tableHTML1 += "<td> " + (fm.statusId === null ? "UnAllocated" : fm.statusId) + "</td>";
                        tableHTML1 += "<td>" + (fm.userId === null ? "" : fm.userId) + "</td>";
                        tableHTML1 += "<td>" + formatDate(fm.startDate) + "</td>";
                        tableHTML1 += "<td>" + formatDate(fm.endDate) + "</td>";
                        tableHTML1 += "<td>" + fm.lbl + "</td>";
                        tableHTML1 += "<td>" + fm.tbl + "</td>";
                        tableHTML1 += "<td>" + fm.totalHBL + "</td>";
                        tableHTML1 += "</tr>";
                    }
                }
                tableHTML1 = tableHTML1 + '</tbody></table></div>';
            }
            else {
                var tableHTMLnodata = '<div class="table-responsive " style="display: inline-block;"><table class="table table-bordered" width="100%" cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
                tableHTMLnodata = tableHTMLnodata + '<thead class="thead-dark"><tr><th hidden></th><th>Activity</th><th>Status</th><th>User</th><th>Start Date</th><th>End Date</th><th>TotalLBL</th><th>TotalTBL</th><th>TotalHBL</th></tr></thead><tbody>';
                var tableHTML1 = tableHTMLnodata + '<tr align="Center" style="padding:2px"><td colspan="6">No Data to Show</td></tr>';
                var tableHTML1 = tableHTML1 + '</tbody></table></div>';
            }

            if (response.hbl.length > 0) {

                for (var i = 0; i < response.hbl.length; i++) {
                    // Get the current hbl object
                    var hbl = response.hbl[i];

                    // Add a new row to the table for the hbl object
                    if (i % 2 == 0) {
                        tableHTML2 += "<tr onclick = formatHBLActivityData('" + hbl.id + "')>";

                        tableHTML2 += "<td hidden>" + hbl.id + "</td>";
                        tableHTML2 += "<td>" + hbl.hblNumber + "</td>";
                        tableHTML2 += "<td>" + hbl.customerName + "</td>";
                        tableHTML2 += "<td>" + hbl.booking + "</td>";
                        tableHTML2 += "</tr>";
                    }
                    else {
                        tableHTML2 += "<tr onclick = formatHBLActivityData('" + hbl.id + "')>";

                        tableHTML2 += "<td hidden>" + hbl.id + "</td>";
                        tableHTML2 += "<td>" + hbl.hblNumber + "</td>";
                        tableHTML2 += "<td>" + hbl.customerName + "</td>";
                        tableHTML2 += "<td>" + hbl.booking + "</td>";
                        tableHTML2 += "</tr>";
                    }
                }
                tableHTML2 = tableHTML2 + '</tbody></table></div>';

            }
            else {
                var tableHTMLnodata = '<div class="table-responsive " style="display: inline-block;"><table class="table table-bordered" width="100%" cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
                tableHTMLnodata = tableHTMLnodata + '<thead class="thead-dark"><tr><th hidden></th><th>HBL #</th><th>Customer Name</th><th>Booking #</th></tr></thead><tbody>';
                var tableHTML2 = tableHTMLnodata + '<tr align="Center" style="padding:2px"><td colspan="6">No Data to Show</td></tr>';
                var tableHTML2 = tableHTML2 + '</tbody></table></div>';
            }

            // Combine the two table divs into a single HTML string
            var combinedHTML = '<div class="row"><div class="col-3">' + tableHTML2 + '</div><div class="col-3">' + tableHTML1 + '</div></div>';

            callback(combinedHTML).show();
        }

    });

}


function UpdateHBLActivity() {

}
$('#search-button').click(function () {
    $('#filesTable').DataTable().ajax.reload();
});
$('#clear-button').click(function () {
    location.reload();
});

function formatDate(data) {
    if (data != null && data != "") {
        var date = new Date(data);
        var month = date.getMonth() + 1;
        var year = date.getFullYear();
        var hr = date.getHours();
        var mn = date.getMinutes();
        var formattedDate = ((month.toString().length > 1 ? month : "0" + month) + "/"
            + (date.getDate().toString().length > 1 ? date.getDate() : "0"
                + date.getDate()) + "/" + date.getFullYear() + " " + (hr.toString().length > 1 ? hr : "0" + hr) + ":" + (mn.toString().length > 1 ? mn : "0" + mn));

        $('#dateTime').val(formattedDate);
        return formattedDate;
    }
    else {

        return "";
    }

}

function setFormattedDateTime() {
    let dateTime = new Date(); // create a new Date object with the current date and time
    let utcDate = dateTime.getUTCDate();
    let utcMonth = dateTime.getUTCMonth() + 1; // getMonth() returns 0-11, so add 1 to get the actual month
    let utcYear = dateTime.getUTCFullYear();
    let utcHours = dateTime.getUTCHours();
    let utcMinutes = dateTime.getUTCMinutes();
    let utcSeconds = dateTime.getUTCSeconds();
    let formattedDateTime = new Date(Date.UTC(utcYear, utcMonth - 1, utcDate, utcHours, utcMinutes, utcSeconds)).toLocaleString('en-US', {
        month: '2-digit',
        day: '2-digit',
        year: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric',
        hour12: true
    }); // format the date and time string in the desired format
    formatDate(formattedDateTime);
    // Set the formatted date and time value to the dateTime input field
}